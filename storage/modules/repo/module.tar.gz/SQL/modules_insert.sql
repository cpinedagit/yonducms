INSERT INTO `modules` (`id`, `module_name`, `module_description`, `module_path`, `module_icon`, `module_type`, `is_deleted`, `enabled`, `is_selected`) VALUES (NULL, 'SampleModule', 'This is a sample module.', 'testmodule.main', 'fa-wrench', 'Test', '0', '1', '0');

INSERT INTO `modules` (`id`, `module_name`, `module_description`, `module_path`, `module_icon`, `module_type`, `is_deleted`, `enabled`, `is_selected`) VALUES (NULL, 'SampleModule2', 'This is another sample module.', 'testmodule2.main', 'fa-wrench', 'Test', '0', '1', '0');
